<?php

class StaleKeyExchangeException extends Exception
{
}
