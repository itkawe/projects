<?php

class UntrustedIdentityException extends Exception
{
}
