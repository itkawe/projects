<?php

interface NewMsgBindInterface
{
    public function process(ProtocolNode $node);
}
